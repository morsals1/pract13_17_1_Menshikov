package com.example.prak13_zad2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class ProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
    }

    fun exit(view: View)
    {
        val intent = Intent(this,SignInActivity::class.java)
        startActivity(intent)
    }
    fun mainscr(view: View)
    {
        val intent = Intent(this,MainscrActivity::class.java)
        startActivity(intent)
    }
}