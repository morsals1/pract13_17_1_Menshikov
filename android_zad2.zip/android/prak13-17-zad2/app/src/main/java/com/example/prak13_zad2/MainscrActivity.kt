package com.example.prak13_zad2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainscrActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mainscr)
    }

    fun profile(view: View)
    {
        val intent = Intent(this,ProfileActivity::class.java)
        startActivity(intent)
    }
}