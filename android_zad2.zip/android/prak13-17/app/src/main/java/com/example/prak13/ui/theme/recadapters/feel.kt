package com.example.prak13.ui.theme.recadapters

import com.example.prak13.R

data class feel(val image:Int, val name_feel:String)
class MyFeel{val list = arrayListOf(feel(R.drawable.calm_ic, ""),
    feel(R.drawable.relax_ic,"Расслабленным"),
    feel(R.drawable.focus_ic,"Сосредоточенным"),
    feel(R.drawable.anxious_ic,"Взволнованным")
)
}
