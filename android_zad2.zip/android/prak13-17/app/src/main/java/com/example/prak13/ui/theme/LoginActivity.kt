package com.example.prak13.ui.theme

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import com.example.prak13.R

class LoginActivity : AppCompatActivity() {
    lateinit var email: EditText
    lateinit var password: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
            email = findViewById(R.id.email)
            password = findViewById(R.id.password)
    }

    fun signin(view: View)
    {
        if(email.text.toString().isEmpty() && password.text.toString().isEmpty())
        {

        }
        else
        {
            val alert = AlertDialog.Builder(this)
                .setTitle("Ошибка")
                .setMessage("У вас есть незаполненные поля")
                .setPositiveButton("OK",null)
                .create()
                .show()
        }
    }

    fun Profile(view: View) {}
}