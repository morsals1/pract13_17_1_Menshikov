package com.example.prak13.ui.theme.recadapters

import com.example.prak13.R

data class state(val title: String, val text_state:String, val image_state:Int)
class Mystate{val state_list = arrayListOf(state("Загаловок статьм", "Краткое описание", R.drawable.state_img_1),
    state("Загаловок бока", "Краткое описание", R.drawable.state_img_2)
)
}
